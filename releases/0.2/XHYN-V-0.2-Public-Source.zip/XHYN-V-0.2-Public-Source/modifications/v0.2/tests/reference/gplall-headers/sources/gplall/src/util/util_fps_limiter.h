#pragma once

#include <array>
#include <optional>

#include "thread.h"
#include "util_time.h"

namespace dxvk {

  class DxvkLatencyTracker;
  
  /**
   * \brief Frame rate limiter
   *
   * Provides functionality to stall an application
   * thread in order to maintain a given frame rate.
   */
  class FpsLimiter {

  public:

    /**
     * \brief Creates frame rate limiter
     */
    FpsLimiter();

    ~FpsLimiter();

    /**
     * \brief Sets target frame rate
     * \param [in] frameRate Target frame rate
     */
    void setTargetFrameRate(double frameRate, uint32_t maxLatency);

    /**
     * \brief Stalls calling thread as necessary
     *
     * Blocks the calling thread if the limiter is enabled
     * and the time since the last call to \ref delay is
     * shorter than the target interval.
     */
    void delay(const Rc<DxvkLatencyTracker>& tracker);

    /**
     * \brief Checks whether the frame rate limiter is enabled
     * \returns \c true if the target frame rate is non-zero.
     */
    bool isEnabled() const {
      return m_targetInterval != TimerDuration::zero();
    }

    /**
     * \brief Queries environment override
     * \returns Frame rate given by environment override
     */
    static std::optional<double> getEnvironmentOverride();

    inline static std::atomic<bool> m_isActive = { false };
    inline static std::atomic<high_resolution_clock::time_point>
      m_lastActive = { high_resolution_clock::now() };

  private:

    using TimePoint = dxvk::high_resolution_clock::time_point;
    using TimerDuration = std::chrono::nanoseconds;

    dxvk::mutex     m_mutex;

    TimerDuration   m_targetInterval  = TimerDuration::zero();
    TimerDuration   m_deviation       = TimerDuration::zero();
    TimePoint       m_lastFrame;

    bool            m_initialized     = false;
    uint32_t        m_maxLatency      = 0;

    bool            m_envOverride     = false;

    void initialize();

  };

}
