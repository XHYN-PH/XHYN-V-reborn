#version 450
layout(location = 0) out vec4 color;
void main() { color = vec4(0.38, 0.12, 0.72, 1.0); }
